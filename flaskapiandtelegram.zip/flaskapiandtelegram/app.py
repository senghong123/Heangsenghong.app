from datetime import date
from flask import Flask, render_template, request, redirect, url_for
import requests

app = Flask(__name__)

@app.route('/')
@app.route('/home')
def get_all_products():
    res = requests.get('https://fakestoreapi.com/products')
    res_json = res.json()
    return render_template('home.html', products=res_json)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    res = requests.get(f'https://fakestoreapi.com/products/{product_id}')
    product = res.json()
    return render_template('product_detail.html', product=product)

@app.route('/checkout/<int:product_id>', methods=['GET', 'POST'])
def checkout(product_id):
    res = requests.get(f'https://fakestoreapi.com/products/{product_id}')
    product = res.json()

    if request.method == 'POST':
        name = request.form['name']
        phone = request.form['phone']
        email = request.form['email']
        address = request.form['address']
        quantity = int(request.form['quantity'])
        total_price = product['price'] * quantity

        msg = (
            "<code> =========[ New Order ]========= </code>\n"
            "<code> - Name: {name}</code>\n"
            "<code> - Phone: {phone}</code>\n"
            "<code> - Email: {email}</code>\n"
            "<code> - Address: {address}</code>\n"
            "<code> - Date: {date}</code>\n"
            "<code> =========[ Order Detail ]========= </code>\n"
            "<b>🔔 Order Detail 🔔</b>\n"
            "<code>1. {product_name} {quantity}x{price} = ${total_price}</code>\n"
        ).format(
            name=name,
            phone=phone,
            email=email,
            address=address,
            date=date.today(),
            product_name=product['title'],
            quantity=quantity,
            price=product['price'],
            total_price=total_price
        )

        send_notification(msg)
        return redirect('/')

    return render_template('checkout.html', product=product)

def send_notification(msg):
    bot_token = '6923334449:AAF_np_s47jHdzOuuSbTkjXq4O76AIvArZA'
    chat_id = '@grouptang'
    url = f"https://api.telegram.org/bot{bot_token}/sendMessage?chat_id={chat_id}&text={requests.utils.quote(msg)}&parse_mode=HTML"
    requests.get(url)

if __name__ == '__main__':
    app.run(debug=True)
